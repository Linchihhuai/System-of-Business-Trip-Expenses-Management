sap.ui.define([
	"fiori/gft/Gestion_Frais_de_Transports/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});